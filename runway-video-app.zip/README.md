# Gerbang — Generator Video AI (Runway API)

Web app sederhana untuk membuat video AI realistis lewat Runway API (Gen-4 / Gen-4.5), dengan mode **teks ke video** dan **gambar ke video**.

## Mengapa ada server.js, bukan cuma index.html?

Dua alasan teknis yang tidak bisa dihindari:

1. **API key harus rahasia.** Kalau API key ditaruh langsung di kode JavaScript yang dibuka di browser, siapa pun bisa membuka "View Source" dan mencurinya, lalu memakai kuota/kredit kamu.
2. **CORS.** Runway tidak mengizinkan permintaan langsung dari browser ke API mereka. Permintaan harus datang dari server.

Jadi `server.js` bertugas sebagai perantara: menyimpan API key dengan aman, meneruskan permintaan ke Runway, dan mengirim hasilnya balik ke halaman web (`public/index.html`).

## Cara menjalankan

1. **Dapatkan API key Runway**
   Daftar/masuk di [dev.runwayml.com](https://dev.runwayml.com), buat API key dari dashboard developer mereka.

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Isi API key**
   ```bash
   cp .env.example .env
   ```
   Buka `.env`, isi:
   ```
   RUNWAY_API_KEY=key_asli_kamu_di_sini
   ```

4. **Jalankan server**
   ```bash
   npm start
   ```

5. Buka browser ke `http://localhost:3000`.

## Struktur file

```
runway-video-app/
├── server.js          # proxy backend ke Runway API
├── package.json
├── .env.example        # salin jadi .env dan isi API key
└── public/
    └── index.html       # antarmuka web
```

## Biaya

Runway membebankan biaya per detik video yang dihasilkan (bukan gratis). Cek harga terbaru di dashboard Runway kamu sebelum generate banyak video — biaya ini di luar kendali aplikasi ini.

## Catatan

- Video hasil generate mengikuti ketentuan penggunaan Runway (termasuk aturan tentang konten yang boleh/tidak boleh dibuat).
- Task video biasanya butuh 30 detik sampai beberapa menit untuk selesai; halaman ini akan otomatis memeriksa status setiap 4 detik.
