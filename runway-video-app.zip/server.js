// server.js
// Small proxy server between your web page and the Runway API.
//
// Why this exists:
// - Runway's API does not allow requests directly from a browser (no CORS),
//   so the browser can't call it on its own.
// - Your Runway API key must never be visible in client-side code, or anyone
//   who opens the page's source could steal it and spend your credits.
// This server holds the key, forwards requests to Runway, and returns the
// result to the page.

import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

const RUNWAY_API_BASE = "https://api.dev.runwayml.com/v1";
const RUNWAY_API_KEY = process.env.RUNWAY_API_KEY;
const RUNWAY_VERSION = "2024-11-06"; // required header for Runway's API

app.use(cors());
app.use(express.json({ limit: "15mb" })); // room for base64 images
app.use(express.static(path.join(__dirname, "public")));

if (!RUNWAY_API_KEY) {
  console.warn(
    "\n⚠️  RUNWAY_API_KEY is not set. Add it to a .env file before generating videos.\n"
  );
}

function runwayHeaders() {
  return {
    Authorization: `Bearer ${RUNWAY_API_KEY}`,
    "Content-Type": "application/json",
    "X-Runway-Version": RUNWAY_VERSION,
  };
}

// Kick off a new generation job (text-to-video or image-to-video)
app.post("/api/generate", async (req, res) => {
  if (!RUNWAY_API_KEY) {
    return res.status(500).json({ error: "Server is missing RUNWAY_API_KEY." });
  }

  const { mode, prompt, promptImage, ratio, duration, seed } = req.body;

  try {
    let endpoint;
    let payload;

    if (mode === "image_to_video") {
      if (!promptImage) {
        return res.status(400).json({ error: "promptImage (base64 or URL) is required for image_to_video." });
      }
      endpoint = `${RUNWAY_API_BASE}/image_to_video`;
      payload = {
        model: "gen4_turbo",
        promptImage,
        promptText: prompt || "",
        ratio: ratio || "1280:720",
        duration: duration || 5,
        ...(seed ? { seed } : {}),
      };
    } else {
      endpoint = `${RUNWAY_API_BASE}/text_to_video`;
      payload = {
        model: "gen4.5",
        promptText: prompt,
        ratio: ratio || "1280:720",
        duration: duration || 5,
        ...(seed ? { seed } : {}),
      };
    }

    const runwayRes = await fetch(endpoint, {
      method: "POST",
      headers: runwayHeaders(),
      body: JSON.stringify(payload),
    });

    const data = await runwayRes.json();

    if (!runwayRes.ok) {
      return res.status(runwayRes.status).json({ error: data.error || "Runway request failed.", details: data });
    }

    // Runway returns a task id; the client will poll /api/status/:id
    res.json({ id: data.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Unexpected server error while starting generation." });
  }
});

// Poll the status of a generation job
app.get("/api/status/:id", async (req, res) => {
  if (!RUNWAY_API_KEY) {
    return res.status(500).json({ error: "Server is missing RUNWAY_API_KEY." });
  }

  try {
    const runwayRes = await fetch(`${RUNWAY_API_BASE}/tasks/${req.params.id}`, {
      headers: runwayHeaders(),
    });
    const data = await runwayRes.json();

    if (!runwayRes.ok) {
      return res.status(runwayRes.status).json({ error: data.error || "Could not fetch task status.", details: data });
    }

    // data.status is one of: PENDING, RUNNING, SUCCEEDED, FAILED
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Unexpected server error while checking status." });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🎬 Server running at http://localhost:${PORT}\n`);
});
